package automation.test;

public class ExternalCallout {
}

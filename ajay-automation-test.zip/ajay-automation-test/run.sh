#!/bin/bash
mvn clean compile exec:java -Dexec.mainClass="automation.test.AutomationManager"